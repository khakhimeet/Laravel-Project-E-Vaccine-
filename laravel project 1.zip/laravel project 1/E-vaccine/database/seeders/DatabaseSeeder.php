<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        ROle::create(['name'=>'admin']);
        ROle::create(['name'=>'hospital']);
        ROle::create(['name'=>'user']);
        // \App\Models\User::factory(10)->create();
    }
}

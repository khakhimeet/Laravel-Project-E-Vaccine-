<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Vaccine;

use function Ramsey\Uuid\v1;

class VaccineController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vaccines= Vaccine::get();
         return view('admin.vaccine.index',compact('vaccines'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.vaccine.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $this->validate($request,[
            'vaccine'=>'required'
        ]);
        Vaccine::create($request->all());
        return redirect()->back()->with('message','Vaccine Added Succesfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $vaccines= Vaccine::find($id);
        return view('admin.vaccine.edit',compact('vaccines'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd("ok");
        $this->validate($request,[
            // 'vaccine'=>'required'
        ]);
        $vaccines=Vaccine::find($id);
        $vaccines->vaccine = $request->vaccine;
        $vaccines->save();
        return redirect()->route('vaccine.index')->with('message','Vaccine  update');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $vaccines=Vaccine::find($id);
        $vaccines->delete();
        return redirect()->route('vaccine.index')->with('message','Vaccine  deleted');
    }
}

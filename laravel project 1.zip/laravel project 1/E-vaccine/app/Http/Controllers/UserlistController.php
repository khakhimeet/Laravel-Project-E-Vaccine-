<?php

namespace App\Http\Controllers;
use App\Models\Booking;
use Illuminate\Http\Request;
use Auth;
class UserlistController extends Controller
{
    public function index(Request $request){

        date_default_timezone_set('Asia/Kolkata');
        if($request->date){
    		$bookings = Booking::latest()->where('date',$request->date)->where('hospital_id',auth()->user()->id)->get();
    		return view('admin.userlist.index',compact('bookings'));
    	}
        $bookings = Booking::latest()->where('date',date('Y-m-d'))->where('hospital_id',auth()->user()->id)->get();
    	return view('admin.userlist.index',compact('bookings'));
    }

    public function toggleStatus($id)
    {
        $bookings  = Booking::find($id);
        $bookings->status =! $bookings->status;
        $bookings->save();
        return redirect()->back();

    }

    public function allTimeAppointment()
    {
        $bookings = Booking::latest()->paginate(20);
        return view('admin.userlist.index',compact('bookings'));
    }


}

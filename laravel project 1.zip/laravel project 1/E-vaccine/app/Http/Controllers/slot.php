<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\Time;
use App\Models\User;
use App\Models\Booking;

class slot extends Controller
{
    public function index(Request $request){
       
          
     date_default_timezone_set('Asia/Kolkata');
     //  dd(date('y-m-d'));

     if(request('date')){
      $hospital = $this->findHospitalBasedOnDate(request('date'));
      return view('admin.slot.index',compact('hospital'));
     // dd($this->findHospitalBasedOnDate(request('date')));
  }

     
        
      $hospital = Appointment::where('date',date('Y-m-d'))->get();
     // return $hospital; 
       //return view('welcome') ;
     return view('admin.slot.index',compact('hospital'));
 
        return view('admin.slot.index');
    }

    public function findHospitalBasedOnDate($date)
    {
        $hospital = Appointment::where('date',$date)->get();
        return $hospital;

    }
}

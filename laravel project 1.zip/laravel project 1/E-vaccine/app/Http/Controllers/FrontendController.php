<?php

namespace App\Http\Controllers;

use App\Http\Middleware\Hospital;
use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\Time;
use App\Models\User;
use App\Models\Booking;


class FrontendController extends Controller
{
   public function index()
   {
       
     date_default_timezone_set('Asia/Kolkata');
     //  dd(date('y-m-d'));

     if(request('date')){
      $hospital = $this->findHospitalBasedOnDate(request('date'));
      return view('welcome',compact('hospital'));
     // dd($this->findHospitalBasedOnDate(request('date')));
  }

     
        
      $hospital = Appointment::where('date',date('Y-m-d'))->get();
     // return $hospital; 
       //return view('welcome') ;
     return view('welcome',compact('hospital'));
 
    }


    public function show($hospitalId,$date)
    {
        $appointment = Appointment::where('user_id',$hospitalId)->where('date',$date)->first();
        $times = Time::where('appointment_id',$appointment->id)->where('status',0)->get();
        // return $times;
        $user = User::where('id',$hospitalId)->first();
        $hospital_id = $hospitalId;

        return view('appointment',compact('times','date','user','hospital_id'));
    }


    public function findHospitalBasedOnDate($date)
    {
        $hospital = Appointment::where('date',$date)->get();
        return $hospital;

    }


    public function store(Request $request)
    {
      date_default_timezone_set('Asia/Kolkata');
        
        $request->validate(['time'=>'required']);
        $check=$this->checkBookingTimeInterval();
        if($check){
            return redirect()->back()->with('errmessage ','You have already bookedn an appointment.Please wait to make next appointment');
          }
   
        
        Booking::create([
            'user_id'=> auth()->user()->id,
            'hospital_id'=> $request->hospitalId,
            'time'=> $request->time,
            'date'=> $request->date,
            'status'=>0
        ]);


        Time::where('appointment_id',$request->appointmentId)->where('time',$request->time)->update(['status'=>1]);
        return redirect()->back()->with('message','Your Appointment was Booked');
        
      }


      public function checkBookingTimeInterval()
      {
          return Booking::orderby('id','desc')
              ->where('user_id',auth()->user()->id)
              ->whereDate('created_at',date('Y-m-d'))
              ->exists();
      }
  
       public function myBookings()
    {
        $appointments = Booking::latest()->where('user_id',auth()->user()->id)->get();
        return view('booking.index',compact('appointments'));
    }

}

<!DOCTYPE html>
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title>E-Vaccine</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>

<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear">
    <div id="logo" class="fl_left"> 
      <!-- ################################################################################################ -->
      
      <h1 class="logoname"><a href="index.html">e-<span>v</span>accine</a></h1>
      <!-- ################################################################################################ -->
    </div>
    <nav id="mainav" class="fl_right"> 
      <!-- ################################################################################################ -->
      <ul class="clear">
        <li class="active"><a href="index.html">Home</a></li>
   
        <li><a href="{{url('/resources/views/auth/login')}}"">Log in </a></li>
        <li><a href="login1.html">Registration</a></li>
        <li><a href="#">about us</a></li>
        <li><a href="file:///F:/e-Vaccine/faq-template/faq.html">FAQ</a></li>
      </ul>
      <!-- ################################################################################################ -->
    </nav>
  </header>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/001.jpg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <h3 class="heading">Covid -19</h3>
      <p>Content goes here</p>
      <!--<footer><a class="btn" href="#">Tristique vehicula</a></footer> -->
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">

  <main class="hoc container clear"> 
    <!-- main body -->
 
    <!-- ################################################################################################ -->
    <section id="introblocks">
      <ul class="nospace group btmspace-80 elements elements-four">
        <li class="one_quarter">
        
          <article><a href="#"><img src="https://img.icons8.com/bubbles/50/000000/protection-mask.png"/></a>
            
            <h6 class="heading">Wear a mask</h6>
            <p>Everyone 2 years and older should wear masks in public.</p><br>
            <p>Masks should be worn in addition to staying at least 6 feet apart, especially around people who don’t live with you.
              <br>
                Wash your hands or use hand sanitizer before putting on your mask.
               <br> Wear your mask over your nose and mouth and secure it under your chin.
            </p>
          
          </article>
        </li>
        <li class="one_quarter">
          <article><a href="#"><img src="https://img.icons8.com/ios-glyphs/30/000000/business-group.png"/></a>
            <h6 class="heading">Stay 6 feet away from others</h6>
            <p><b>Inside your home:</b> Avoid close contact with people who are sick.  </p><br>
            <p>
              <b>Outside your home: </b>  Put 6 feet of distance between yourself and people who don’t live in your household.
              <br>
                  Remember that some people without symptoms may be able to spread virus.<br>
                  Stay at least 6 feet (about 2 arm lengths) from other people.<br> 
              
            </p>
          </article>
        </li>
        <li class="one_quarter">


          


          <article><a href="#"><img src="https://img.icons8.com/bubbles/50/000000/coughing.png"/></a>
            <h6 class="heading">  Cover coughs and sneezes </h6>
            <p>
              <b>

                If you are wearing a mask:
              </b>
               You can cough or sneeze into your mask. Put on a new, clean mask as soon as possible and wash your hands.<br>
            </p><br>
            <p>
              <b>
                If you are not wearing a mask:
              </b>
              
                  Always cover your mouth and nose with a tissue when you cough or sneeze, or use the inside of your elbow and do not spit.<br>
                  Throw used tissues in the trash.
                  
            </p>
          </article>
        </li>
        <li class="one_quarter">
          <article><a href="#"><img src="https://img.icons8.com/ios-filled/50/000000/health-checkup.png"/></a>
            <h6 class="heading">Monitor your health daily</h6>
            <p><b>Be alert for symptoms.</b> Watch for fever, cough, shortness of breath, or other symptoms of COVID-19.</p><br>
            <p>
              <b>
                Take your temperature if symptoms develop.

              </b>
              Don’t take your temperature within 30 minutes of exercising or after taking medications that could lower your temperature, like acetaminophen.
            </p>
          </article>
        </li>
      </ul>
   
    </section>
    <!-- ################################################################################################ -->
     
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper gradient">
  <div class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <div class="sectiontitle">

      <h6 class="heading font-x2">vaccine Details</h6>
    </div>
    <ul class="nospace group team">
      <li class="one_third first">
        <figure><a class="imgover" href="#"><img src="images/demo/vaccine1.jpg" alt="" width="380" height="400"></a>
          <figcaption><strong>COVISHIELD </strong> <em>Made in India</em></figcaption>
        </figure>
      </li>
      <li class="one_third">
        <figure><a class="imgover" href="#"><img src="images/demo/vaccine2.jpg" alt="" width="380" height="400"></a>
          <figcaption><strong>COVAXIN</strong> <em>Made in India</em></figcaption>
        </figure>
      </li>
      <li class="one_third">
        <figure><a class="imgover" href="#"><img src="images/demo/vaccine3.jpg" alt="" width="380" height="400"></a>
          <figcaption><strong>SPUTNIK</strong> <em>Made in Russia</em></figcaption>
        </figure>
      </li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->



<div class="bgded overlay light" style="background-image:url('images/demo/backgrounds/002.jpg');">
  <section id="services" class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <div class="sectiontitle">
      
      <h6 class="heading font-x2">Image Gallery</h6>
    </div>
    <ul class="nospace group elements elements-three">
      <li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li>
      <li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li>
      <li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li><li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li>
      
      <li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li>
      <li class="one_third">
        <article><img src="images/demo/backgrounds/002.jpg" >
          </article>
      </li>
      
    </ul>
    <!-- ################################################################################################ -->
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper coloured"  style="background-image:url('images/demo/04.jpg');">
  <section id="testimonials" class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <div class="sectiontitle">
      
      <h6 class="heading font-x2">Developer</h6>
    </div>
     <article class="one_half first">
      <figure class="clear"><img src="images/demo/100x100.png" alt="">
        <figcaption>
          <h6 class="heading">Rajan Ramavat </h6>
          <em>Laravel developer</em></figcaption>
      </figure>
      <blockquote>Quote goes here</blockquote>
    </article>
    <article class="one_half">
      <figure class="clear"><img src="images/demo/100x100.png" alt="">
        <figcaption>
          <h6 class="heading">Meet Khakhi</h6>
          <em>Laravel developer</em></figcaption>
      </figure>
      <blockquote>Quote goes here</blockquote>
    </article>
    <!-- ################################################################################################ -->
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <section id="ctdetails" class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <div class="sectiontitle">
      <p class="nospace font-xs">any query</p>
      <h6 class="heading font-x2">conect </h6>
    </div>
    <figure class="one_half first">
      <ul class="nospace clear"><br>
        <br>
        <br>
        <br>
        <br><br>
        <li class="block clear"><a href="#"><i class="fas fa-phone"></i></a> <span><strong>Give us a call:</strong> +91 9712142532</span></li>
        <li class="block clear"><a href="#"><i class="fas fa-envelope"></i></a> <span><strong>Send us a mail:</strong> meet.khakhi176772@marwadiuniversity.ac.in</span></li>

      </ul>
    </figure>
    <article class="one_half">
      <h6 class="heading">feedback</h6>
      <p class="nospace btmspace-15">comments</p>
      <form action="#" method="post">
        <fieldset>
          <legend>Newsletter:</legend>
          <label for="name">Name <span>*</span></label>
          <input type="text" name="name" id="name" value="" size="22" required>
          <label for="email">Mail <span>*</span></label>
          <input type="email" name="email" id="email" value="" size="22" required>
          <label for="comment">Your Comment</label>
          <textarea name="comment" id="comment" cols="25" rows="10"  placeholder="Give your comments here"></textarea>
            
            
          <button type="submit" value="submit">Submit</button>
        </fieldset>
      </form>
      
    </article>
    <!-- ################################################################################################ -->
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="bgded overlay row4" style="background-image:url('images/demo/backgrounds/001.jpg');">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="center" >
        <h1 class="logoname"><a href="index.html">e-<span>v</span>accine</a></h1>
 
    <div class="center" >
      <ul class="faico clear">
        <br>
        <br>
        <li><a class="faicon-facebook" href="#"><i class="fab fa-facebook"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fab fa-google-plus-g"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fab fa-linkedin"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fab fa-twitter"></i></a></li>
        
      </ul>
     </div> 
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2021 - All Rights Reserved - <a href="#">Domain Name goes here</a></p>
    <p class="fl_right">Template by <a target="_blank" href="#" title="Free Website Templates">Rajan Ramavat & Meet Khakhi</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fas fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<!-- Homepage specific -->
<script src="layout/scripts/jquery.easypiechart.min.js"></script>
<!-- / Homepage specific -->
</body>
</html>